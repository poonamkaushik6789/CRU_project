const assetsRootPath = '../res/assets/'


const kitchen = require(`${assetsRootPath}kitchen.png`);
const eye_icon = require(`${assetsRootPath}eye_icon.png`);
const eye_icon_hide = require(`${assetsRootPath}eye_icon_hide.png`);
const email_icon = require(`${assetsRootPath}email_icon.png`);
const backarrow = require(`${assetsRootPath}backarrow.png`);
const rightarrow = require(`${assetsRootPath}rightarrow.png`);
const dest = require(`${assetsRootPath}dest.png`);
const womenmassa = require(`${assetsRootPath}womenmassa.png`);
const temp = require(`${assetsRootPath}temp.png`);
const mask = require(`${assetsRootPath}mask.png`);
const testing = require(`${assetsRootPath}testing.png`);
const percentage = require(`${assetsRootPath}percentage.png`);
const vacin = require(`${assetsRootPath}vacin.png`);
const massage = require(`${assetsRootPath}massage.png`);
const rightadd = require(`${assetsRootPath}rightadd.png`);
const star = require(`${assetsRootPath}star.png`);
const secure = require(`${assetsRootPath}secure.png`);
const logo = require(`${assetsRootPath}vca-business-logo.png`);
const nodata = require(`${assetsRootPath}nodata.png`);
const home = require(`${assetsRootPath}home.png`);
const menu = require(`${assetsRootPath}menu.png`);
const logoutIcon = require(`${assetsRootPath}logout_icon.png`);
const menuIcon = require(`${assetsRootPath}menu_icon.png`);
const viewIcon = require(`${assetsRootPath}view_icon.png`);
const mor = require(`${assetsRootPath}mor.png`);
const moreoption = require(`${assetsRootPath}moreoption.png`);
const moreoption1 = require(`${assetsRootPath}moreoption1.png`);
const threedot = require(`${assetsRootPath}threedot.png`);
const back = require(`${assetsRootPath}back.png`);
const plus1 = require(`${assetsRootPath}plus1.png`);

const internet = require(`${assetsRootPath}internet.png`);
const textmess = require(`${assetsRootPath}textmess.png`);
const man = require(`${assetsRootPath}man.png`);
const dropdown = require(`${assetsRootPath}dropdown.png`);
const homeclap = require(`${assetsRootPath}homeclap.png`);
const bookclap = require(`${assetsRootPath}bookclap.png`);
const securityclap = require(`${assetsRootPath}securityclap.png`);
const profileclap = require(`${assetsRootPath}profileclap.png`);
const editclap = require(`${assetsRootPath}editclap.png`);
const msgclap = require(`${assetsRootPath}msgclap.png`);
const plusclap = require(`${assetsRootPath}plusclap.png`);
const handshake = require(`${assetsRootPath}handshake.png`);
const locationclap = require(`${assetsRootPath}locationclap.png`);
const ucclap = require(`${assetsRootPath}ucclap.png`);
const shareclap = require(`${assetsRootPath}shareclap.png`);
const starclap = require(`${assetsRootPath}starclap.png`);
const giftclap = require(`${assetsRootPath}giftclap.png`);
const walletclap = require(`${assetsRootPath}walletclap.png`);
const ratethumbclap = require(`${assetsRootPath}ratethumbclap.png`);
const settingclap = require(`${assetsRootPath}settingclap.png`);
const payclap = require(`${assetsRootPath}payclap.png`);
const referclap = require(`${assetsRootPath}referclap.png`);
const plusclapblu = require(`${assetsRootPath}plusclapblu.png`);
const rightclap = require(`${assetsRootPath}rightclap.png`);
const manclap = require(`${assetsRootPath}manclap.png`);
const womanclap = require(`${assetsRootPath}womanclap.png`);
const circlearrow = require(`${assetsRootPath}circlearrow.png`);
const hundred = require(`${assetsRootPath}hundred.png`);
const fonhand = require(`${assetsRootPath}fonhand.png`);
const salonman = require(`${assetsRootPath}salonman.png`);
const salonwoman = require(`${assetsRootPath}salonwoman.png`);
const repairclap = require(`${assetsRootPath}repairclap.png`);
const cleanclap = require(`${assetsRootPath}cleanclap.png`);
const bac = require(`${assetsRootPath}bac.png`);
const greenright = require(`${assetsRootPath}greenright.png`);
const rightdiffgreen = require(`${assetsRootPath}rightdiffgreen.png`);
const bookmark = require(`${assetsRootPath}bookmark.png`);
const coins = require(`${assetsRootPath}coins.png`);
const blackbook = require(`${assetsRootPath}blackbook.png`);
const fillstarclap = require(`${assetsRootPath}fillstarclap.png`);
const boxicon = require(`${assetsRootPath}boxicon.png`);
const proclap = require(`${assetsRootPath}proclap.png`);
const dropclap = require(`${assetsRootPath}dropclap.png`);
const phoneclap = require(`${assetsRootPath}phoneclap.png`);
const purifier = require(`${assetsRootPath}purifier.png`);
const gyser = require(`${assetsRootPath}gyser.png`);
const micro = require(`${assetsRootPath}micro.png`);
const refig = require(`${assetsRootPath}refig.png`);
const air = require(`${assetsRootPath}air.png`);
const washing = require(`${assetsRootPath}washing.png`);
const bargraph = require(`${assetsRootPath}bargraph.png`);
const uclogo = require(`${assetsRootPath}uclogo.png`);
const clockclap = require(`${assetsRootPath}clockclap.png`);
const videocall = require(`${assetsRootPath}videocall.png`);
const prog = require(`${assetsRootPath}prog.png`);
const one = require(`${assetsRootPath}one.png`);
const two = require(`${assetsRootPath}two.png`);
const thre = require(`${assetsRootPath}thre.png`);
const four = require(`${assetsRootPath}four.png`);
const info = require(`${assetsRootPath}info.png`);
const accuracy = require(`${assetsRootPath}accuracy.png`);
const rupee = require(`${assetsRootPath}rupee.png`);
const fastcharge = require(`${assetsRootPath}fastcharge.png`);
const expimg = require(`${assetsRootPath}expimg.png`);
const trophy = require(`${assetsRootPath}trophy.png`);
const fillstar = require(`${assetsRootPath}fillstar.png`);
const lock = require(`${assetsRootPath}lock.png`);
const vacc = require(`${assetsRootPath}vacc.png`);
const womansalon = require(`${assetsRootPath}womansalon.png`);
const currentloc = require(`${assetsRootPath}currentloc.png`);
const google = require(`${assetsRootPath}google.png`);
const best = require(`${assetsRootPath}best.png`);
const startuc = require(`${assetsRootPath}startuc.png`);
const membership = require(`${assetsRootPath}membership.png`);
const paycredit = require(`${assetsRootPath}paycredit.png`);
const ratingstar = require(`${assetsRootPath}ratingstar.png`);
const heartinhand = require(`${assetsRootPath}heartinhand.png`);
const cleanhome = require(`${assetsRootPath}cleanhome.png`);
const plumclaphome = require(`${assetsRootPath}plumclaphome.png`);
const valen = require(`${assetsRootPath}valen.png`);
const redarrow = require(`${assetsRootPath}redarrow.png`);
const lock_icon = require(`${assetsRootPath}lock_icon.png`);
const loginBgIcon = require(`${assetsRootPath}login_bg_icon.png`);
const fb = require(`${assetsRootPath}fb.png`);
const linkdin = require(`${assetsRootPath}linkdin.png`);
const producer = require(`${assetsRootPath}producer.png`);
const camrea = require(`${assetsRootPath}camrea.png`);
const calendar_icon = require(`${assetsRootPath}calendar_icon.png`);
const timer = require(`${assetsRootPath}timer.png`);
const like = require(`${assetsRootPath}like.png`);
const chat = require(`${assetsRootPath}chat.png`);

const closetoday = require(`${assetsRootPath}closetoday.png`);
const notification_icon = require(`${assetsRootPath}notification_icon.png`);
const rawartist = require(`${assetsRootPath}rawartist.png`);
const gearexpo = require(`${assetsRootPath}gearexpo.png`);
const conference = require(`${assetsRootPath}conference.png`);
const filmmakers = require(`${assetsRootPath}filmmakers.png`);
const filmfestival = require(`${assetsRootPath}filmfestival.png`);
const msgs = require(`${assetsRootPath}msgs.png`);
const social = require(`${assetsRootPath}social.png`);
const event = require(`${assetsRootPath}event.png`);
const cru = require(`${assetsRootPath}cru.png`);
const job = require(`${assetsRootPath}job.png`);
const project = require(`${assetsRootPath}project.png`);
const map = require(`${assetsRootPath}map.png`);
const locator = require(`${assetsRootPath}locator.png`);
const setting = require(`${assetsRootPath}setting.png`);
const Cross = require(`${assetsRootPath}Cross.png`);
const tik = require(`${assetsRootPath}tik.png`);
const search = require(`${assetsRootPath}search.png`);
const notifications = require(`${assetsRootPath}notifications.png`);
const googlemap = require(`${assetsRootPath}googlemap.png`);
const Sendicon = require(`${assetsRootPath}Sendicon.png`);
const profile = require(`${assetsRootPath}profile.png`);
const grouprofile = require(`${assetsRootPath}grouprofile.png`);
const socialcolor = require(`${assetsRootPath}socialcolor.png`);
const redlike = require(`${assetsRootPath}redlike.png`);
const my_cru = require(`${assetsRootPath}my_cru.png`);
const about = require(`${assetsRootPath}about.png`);
 const users = require(`${assetsRootPath}users.png`);
 const cross_icon = require(`${assetsRootPath}cross_icon.png`);
 const green_tik = require(`${assetsRootPath}green_tik.png`);



const ImageIcons = {
  rightarrow,
  cross_icon,
  green_tik,
  my_cru,
  users,
  about,
  redlike,
  notification_icon,
  closetoday,
  backarrow,
  fb,
  linkdin,
  camrea,
  calendar_icon,
  lock_icon,
  timer,
  like,
  chat,
  eye_icon,
  eye_icon_hide,
  email_icon,
  best,
  redarrow,
  valen,
  cleanhome,
  plumclaphome,
  heartinhand,
  ratingstar,
  paycredit,
  membership,
  startuc,
  womenmassa,
  loginBgIcon,
  prog,
  google,
  currentloc,
  womansalon,
  vacc,
  lock,
  trophy,
  fillstar,
  expimg,
  fastcharge,
  rupee,
  accuracy,
  info,
  one,
  two,
  thre,
  four,
  videocall,
  clockclap,
  uclogo,
  bargraph,
  secure,
  mask,
  dest,
  temp,
  vacin,
  testing,
  percentage,
  massage,
  rightadd,
  star,
  logo,
  washing,
  air,
  refig,
  gyser,
  micro,
  phoneclap,
  purifier,
  dropclap,
  boxicon,
  proclap,
  fillstarclap,
  blackbook,
  coins,
  bookmark,
  rightdiffgreen,
  greenright,
  bac,
  cleanclap,
  repairclap,
  fonhand,
  salonman,
  salonwoman,
  hundred,
  circlearrow,
  womanclap,
  manclap,
  rightclap,
  plusclapblu,
  referclap,
  ratethumbclap,
  giftclap,
  payclap,
  settingclap,
  walletclap,
  starclap,
  shareclap,
  ucclap,
  locationclap,
  handshake,
  plusclap,
  msgclap,
  editclap,
  profileclap,
  homeclap,
  securityclap,
  bookclap,
  dropdown,
  man,
  textmess,
  internet,
  moreoption1,
  back,
  plus1,
  threedot,
  moreoption,
  mor,
  nodata,
  home,
  menu,
  logoutIcon,
  menuIcon,
  viewIcon,
  kitchen,
  producer,
  rawartist,
  gearexpo,
  conference,
  filmmakers,
  filmfestival,
  msgs,
  social,
  event,
  cru,
  project,
  job,
  map,
  locator,
  setting,
  Cross,
  tik,
  search,
  notifications,
  googlemap,
  Sendicon,
  profile,
  grouprofile,
  socialcolor,
};
export default ImageIcons;
