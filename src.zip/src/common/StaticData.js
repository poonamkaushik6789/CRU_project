
const discountOptions=[
    { label: 'Buy 1, get 1 free', value: 'discountType1' },
    { label: 'Buy 1, get 50% off 2nd item', value: 'discountType2' },
    { label: '% off', value: 'discountType3' },
    { label: '$ off', value: 'discountType4' },
    { label: 'Free Sample/item', value: 'discountType5' },
    { label: 'Custom', value: 'discountType6' },
]

export {
    discountOptions 
}

