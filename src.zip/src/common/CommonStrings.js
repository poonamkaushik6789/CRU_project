

const CommonStrings={
    AppName:"VCA"
}

export default CommonStrings;

