import React, { useState } from 'react';
import { Text, Image, TextInput, View, TouchableOpacity } from 'react-native';
import { Colors } from '../../common'
//import DropDownPicker from 'react-native-dropdown-picker';
import styles from './styles';

const Footer = (props) => {

    return (
            <View>
            <Text>HELLOOOO</Text>
            </View>
    )
}

export default Footer;