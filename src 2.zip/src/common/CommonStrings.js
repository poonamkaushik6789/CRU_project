

const CommonStrings={
    AppName:"Filmca"
}

export default CommonStrings;

